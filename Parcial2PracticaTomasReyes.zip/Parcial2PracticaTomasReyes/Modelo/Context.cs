﻿using System.Data.Entity;

namespace Modelo
{
    public class Context : DbContext
    {
        public Context() : base("Context") { }

        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<CuentaCorriente> CuentasCorrientes { get; set; }
        public DbSet<Movimiento> Movimientos { get; set; }
    }
}
