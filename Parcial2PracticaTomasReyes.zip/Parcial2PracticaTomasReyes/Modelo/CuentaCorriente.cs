﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class CuentaCorriente
    {
        public int CuentaCorrienteId { get; set; }
        public int ClienteId { get; set; }
        public string NumeroCuenta { get; set; }
        public decimal SaldoInicial { get; set; }
    }
}
