﻿using Modelo;
using System.Collections.Generic;
using System.Linq;

namespace Controladora
{
    public class ClientesController
    {
        private readonly Context db = new Context();

        public List<Cliente> ObtenerTodos()
        {
            return db.Clientes.ToList();
        }

        public void Agregar(Cliente c)
        {
            db.Clientes.Add(c);
            db.SaveChanges();
        }

        public void Editar(Cliente c)
        {
            var original = db.Clientes.Find(c.ClienteId);

            if (original != null)
            {
                original.Nombre = c.Nombre;
                original.Apellido = c.Apellido;
                original.DNI = c.DNI;
                original.Telefono = c.Telefono;

                db.SaveChanges();
            }
        }

        public void Eliminar(int id)
        {
            var c = db.Clientes.Find(id);

            if (c != null)
            {
                db.Clientes.Remove(c);
                db.SaveChanges();
            }
        }
    }
}
