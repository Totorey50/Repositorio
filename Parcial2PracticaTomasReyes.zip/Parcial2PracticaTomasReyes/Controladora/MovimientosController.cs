﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Controladora
{
    public class MovimientosController
    {
        private static List<Movimiento> _movs = new List<Movimiento>();
        private static int _nextId = 1;

        public List<Movimiento> ObtenerPorCuenta(int cuentaId)
        {
            return _movs.Where(x => x.CuentaId == cuentaId).OrderByDescending(m => m.Fecha).ToList();
        }

        public void Agregar(Movimiento m)
        {
            m.MovimientoId = _nextId++;
            m.Fecha = DateTime.Now;
            _movs.Add(m);
        }

        public decimal CalcularSaldo(int cuentaId, decimal saldoInicial = 0)
        {
            var movimientos = ObtenerPorCuenta(cuentaId);
            decimal saldo = saldoInicial;
            foreach (var m in movimientos)
            {
                if (m.Tipo.ToUpper() == "CREDITO") saldo += m.Monto;
                else saldo -= m.Monto;
            }
            return saldo;
        }
    }
}
