﻿using Modelo;
using System.Collections.Generic;
using System.Linq;

namespace Controladora
{
    public class CuentasController
    {
        private static List<CuentaCorriente> _cuentas = new List<CuentaCorriente>();
        private static int _nextId = 1;

        public List<CuentaCorriente> ObtenerTodas()
        {
            return _cuentas.ToList();
        }

        public void Agregar(CuentaCorriente c)
        {
            c.CuentaCorrienteId = _nextId++;
            _cuentas.Add(c);
        }

        public void Eliminar(int id)
        {
            var cta = _cuentas.FirstOrDefault(x => x.CuentaCorrienteId == id);
            if (cta != null) _cuentas.Remove(cta);
        }
    }
}
