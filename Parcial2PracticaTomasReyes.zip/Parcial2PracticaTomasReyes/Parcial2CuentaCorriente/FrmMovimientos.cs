﻿using System;
using System.Linq;
using System.Windows.Forms;
using Modelo;
using Controladora;

namespace Parcial2CuentaCorriente
{
    public partial class FrmMovimientos : Form
    {
        private readonly CuentasController _cuentasController = new CuentasController();
        private readonly MovimientosController _movController = new MovimientosController();

        public FrmMovimientos()
        {
            InitializeComponent();
        }

        private void FrmMovimientos_Load(object sender, EventArgs e)
        {
            CargarCuentas();
            cboTipo.Items.AddRange(new[] { "CREDITO", "DEBITO" });
        }

        private void CargarCuentas()
        {
            var cuentas = _cuentasController.ObtenerTodas()
                .Select(c => new { c.CuentaCorrienteId, Descr = c.NumeroCuenta })
                .ToList();

            cboCuentas.DataSource = cuentas;
            cboCuentas.DisplayMember = "Descr";
            cboCuentas.ValueMember = "CuentaCorrienteId";
            cboCuentas.SelectedIndex = -1;
        }

        private void CargarMovimientos(int cuentaId)
        {
            dgvMovimientos.DataSource = null;
            dgvMovimientos.DataSource = _movController.ObtenerPorCuenta(cuentaId);
        }

        private void cboCuentas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboCuentas.SelectedValue == null) return;
            if (cboCuentas.SelectedValue is System.Data.DataRowView) return;
            int cuentaId = Convert.ToInt32(cboCuentas.SelectedValue);
            CargarMovimientos(cuentaId);
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (cboCuentas.SelectedValue == null || cboTipo.SelectedItem == null || !decimal.TryParse(txtMonto.Text, out decimal monto))
            {
                MessageBox.Show("Complete los campos correctamente.");
                return;
            }

            var mov = new Movimiento
            {
                CuentaId = Convert.ToInt32(cboCuentas.SelectedValue),
                Tipo = cboTipo.SelectedItem.ToString(),
                Monto = monto,
                Fecha = DateTime.Now
            };

            _movController.Agregar(mov);
            CargarMovimientos(mov.CuentaId);
        }
    }
}
