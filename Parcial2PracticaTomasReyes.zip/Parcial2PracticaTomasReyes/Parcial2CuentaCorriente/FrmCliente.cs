﻿using System;
using System.Windows.Forms;
using Modelo;
using Controladora;

namespace Parcial2CuentaCorriente
{
    public partial class FrmClientes : Form
    {
        private readonly ClientesController _clientesController = new ClientesController();

        public FrmClientes()
        {
            InitializeComponent();
        }

        private void FrmClientes_Load(object sender, EventArgs e)
        {
            CargarClientes();
        }

        private void CargarClientes()
        {
            dgvClientes.DataSource = null;
            dgvClientes.DataSource = _clientesController.ObtenerTodos();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtDNI.Text))
            {
                MessageBox.Show("Complete los campos obligatorios (Nombre, Apellido, DNI).");
                return;
            }

            var c = new Cliente
            {
                Nombre = txtNombre.Text.Trim(),
                Apellido = txtApellido.Text.Trim(),
                DNI = txtDNI.Text.Trim(),
                Telefono = txtTelefono.Text.Trim()
            };

            _clientesController.Agregar(c);
            CargarClientes();
            Limpiar();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un cliente.");
                return;
            }

            var c = new Cliente
            {
                ClienteId = Convert.ToInt32(dgvClientes.CurrentRow.Cells["ClienteId"].Value),
                Nombre = txtNombre.Text.Trim(),
                Apellido = txtApellido.Text.Trim(),
                DNI = txtDNI.Text.Trim(),
                Telefono = txtTelefono.Text.Trim()
            };

            _clientesController.Editar(c);
            CargarClientes();
            Limpiar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un cliente.");
                return;
            }

            int id = Convert.ToInt32(dgvClientes.CurrentRow.Cells["ClienteId"].Value);

            _clientesController.Eliminar(id);
            CargarClientes();
            Limpiar();
        }

        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvClientes.CurrentRow == null) return;

            txtNombre.Text = dgvClientes.CurrentRow.Cells["Nombre"].Value?.ToString();
            txtApellido.Text = dgvClientes.CurrentRow.Cells["Apellido"].Value?.ToString();
            txtDNI.Text = dgvClientes.CurrentRow.Cells["DNI"].Value?.ToString();
            txtTelefono.Text = dgvClientes.CurrentRow.Cells["Telefono"].Value?.ToString();
        }

        private void Limpiar()
        {
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDNI.Text = "";
            txtTelefono.Text = "";
        }
    }
}
