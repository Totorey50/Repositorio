﻿using System;
using System.Linq;
using System.Windows.Forms;
using Modelo;
using Controladora;

namespace Parcial2CuentaCorriente
{
    public partial class FrmCuentas : Form
    {
        private readonly ClientesController _clientesController = new ClientesController();
        private readonly CuentasController _cuentasController = new CuentasController();
        private readonly MovimientosController _movController = new MovimientosController();

        public FrmCuentas()
        {
            InitializeComponent();
        }

        private void FrmCuentas_Load(object sender, EventArgs e)
        {
            CargarClientes();
            CargarCuentas();
        }

        private void CargarClientes()
        {
            var clientes = _clientesController.ObtenerTodos()
                .Select(c => new { c.ClienteId, NombreCompleto = c.Nombre + " " + c.Apellido })
                .ToList();

            cboClientes.DataSource = clientes;
            cboClientes.DisplayMember = "NombreCompleto";
            cboClientes.ValueMember = "ClienteId";
            cboClientes.SelectedIndex = -1;
        }

        private void CargarCuentas()
        {
            var cuentas = _cuentasController.ObtenerTodas()
                .Select(c => new
                {
                    c.CuentaCorrienteId,
                    c.NumeroCuenta,
                    Cliente = (_clientesController.ObtenerTodos().FirstOrDefault(cl => cl.ClienteId == c.ClienteId)?.Nombre ?? "") + " " +
                              (_clientesController.ObtenerTodos().FirstOrDefault(cl => cl.ClienteId == c.ClienteId)?.Apellido ?? ""),
                    Saldo = _movController.CalcularSaldo(c.CuentaCorrienteId, c.SaldoInicial)
                })
                .ToList();

            dgvCuentas.DataSource = null;
            dgvCuentas.DataSource = cuentas;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (cboClientes.SelectedValue == null || string.IsNullOrWhiteSpace(txtNumeroCuenta.Text))
            {
                MessageBox.Show("Seleccione un cliente y complete el número de cuenta.");
                return;
            }

            var c = new CuentaCorriente
            {
                NumeroCuenta = txtNumeroCuenta.Text.Trim(),
                ClienteId = Convert.ToInt32(cboClientes.SelectedValue),
                SaldoInicial = decimal.TryParse(txtSaldo.Text.Trim(), out decimal s) ? s : 0m
            };

            _cuentasController.Agregar(c);
            Limpiar();
            CargarCuentas();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvCuentas.CurrentRow == null) { MessageBox.Show("Seleccione una cuenta."); return; }

            int id = Convert.ToInt32(dgvCuentas.CurrentRow.Cells["CuentaCorrienteId"].Value);
            _cuentasController.Eliminar(id);
            CargarCuentas();
        }

        private void dgvCuentas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCuentas.CurrentRow == null) return;

            txtNumeroCuenta.Text = dgvCuentas.CurrentRow.Cells["NumeroCuenta"].Value?.ToString();
            txtSaldo.Text = dgvCuentas.CurrentRow.Cells["Saldo"].Value?.ToString();
            int cuentaId = Convert.ToInt32(dgvCuentas.CurrentRow.Cells["CuentaCorrienteId"].Value);
            var cta = _cuentasController.ObtenerTodas().FirstOrDefault(x => x.CuentaCorrienteId == cuentaId);
            if (cta != null)
            {
                cboClientes.SelectedValue = cta.ClienteId;
            }
        }

        private void Limpiar()
        {
            txtNumeroCuenta.Text = "";
            txtSaldo.Text = "";
            cboClientes.SelectedIndex = -1;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
