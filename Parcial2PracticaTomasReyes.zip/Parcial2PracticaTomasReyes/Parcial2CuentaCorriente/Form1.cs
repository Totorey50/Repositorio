﻿using System;
using System.Windows.Forms;

namespace Parcial2CuentaCorriente
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            FrmClientes frm = new FrmClientes();
            frm.Show();
        }

        private void btnCuentas_Click(object sender, EventArgs e)
        {
            FrmCuentas frm = new FrmCuentas();
            frm.Show();
        }

        private void btnMovimientos_Click(object sender, EventArgs e)
        {
            FrmMovimientos frm = new FrmMovimientos();
            frm.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
