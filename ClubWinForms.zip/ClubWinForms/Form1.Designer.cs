﻿namespace ClubWinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtId = new TextBox();
            label3 = new Label();
            txtNombre = new TextBox();
            txtApellido = new TextBox();
            txtDNI = new TextBox();
            txtNumeroSocio = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            dtpFechaNacimiento = new DateTimePicker();
            label8 = new Label();
            chkCuotaAlDia = new CheckBox();
            btnAgregar = new Button();
            btnModificar = new Button();
            btnEliminar = new Button();
            btnListar = new Button();
            btnContarCuota = new Button();
            txtEdadFiltro = new TextBox();
            btnFiltrarEdad = new Button();
            btnLimpiar = new Button();
            dgvSocios = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvSocios).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 27);
            label1.Name = "label1";
            label1.Size = new Size(127, 20);
            label1.TabIndex = 0;
            label1.Text = "Gestión de Socios";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(117, 77);
            label2.Name = "label2";
            label2.Size = new Size(22, 20);
            label2.TabIndex = 1;
            label2.Text = "Id";
            // 
            // txtId
            // 
            txtId.Location = new Point(175, 70);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(250, 27);
            txtId.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(75, 127);
            label3.Name = "label3";
            label3.Size = new Size(64, 20);
            label3.TabIndex = 3;
            label3.Text = "Nombre";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(175, 124);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(250, 27);
            txtNombre.TabIndex = 4;
            // 
            // tcxtApellido
            // 
            txtApellido.Location = new Point(175, 172);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(250, 27);
            txtApellido.TabIndex = 5;
            // 
            // txtDNI
            // 
            txtDNI.Location = new Point(175, 214);
            txtDNI.Name = "txtDNI";
            txtDNI.Size = new Size(250, 27);
            txtDNI.TabIndex = 6;
            // 
            // txtNumeroSocio
            // 
            txtNumeroSocio.Location = new Point(175, 258);
            txtNumeroSocio.Name = "txtNumeroSocio";
            txtNumeroSocio.Size = new Size(250, 27);
            txtNumeroSocio.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(75, 172);
            label4.Name = "label4";
            label4.Size = new Size(66, 20);
            label4.TabIndex = 8;
            label4.Text = "Apellido";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(106, 217);
            label5.Name = "label5";
            label5.Size = new Size(35, 20);
            label5.TabIndex = 9;
            label5.Text = "DNI";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(37, 258);
            label6.Name = "label6";
            label6.Size = new Size(104, 20);
            label6.TabIndex = 10;
            label6.Text = "Numero Socio";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 299);
            label7.Name = "label7";
            label7.Size = new Size(128, 20);
            label7.TabIndex = 11;
            label7.Text = "Fecha Nacimiento";
            // 
            // dtpFechaNacimiento
            // 
            dtpFechaNacimiento.Location = new Point(175, 299);
            dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            dtpFechaNacimiento.Size = new Size(250, 27);
            dtpFechaNacimiento.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(51, 343);
            label8.Name = "label8";
            label8.Size = new Size(89, 20);
            label8.TabIndex = 13;
            label8.Text = "Cuota al día";
            // 
            // chkCuotaAlDia
            // 
            chkCuotaAlDia.AutoSize = true;
            chkCuotaAlDia.Location = new Point(175, 346);
            chkCuotaAlDia.Name = "chkCuotaAlDia";
            chkCuotaAlDia.Size = new Size(18, 17);
            chkCuotaAlDia.TabIndex = 14;
            chkCuotaAlDia.UseVisualStyleBackColor = true;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(494, 73);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(94, 29);
            btnAgregar.TabIndex = 15;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            // 
            // btnModificar
            // 
            btnModificar.Location = new Point(494, 127);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new Size(94, 29);
            btnModificar.TabIndex = 16;
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(494, 172);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(94, 29);
            btnEliminar.TabIndex = 17;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            // 
            // btnListar
            // 
            btnListar.Location = new Point(494, 214);
            btnListar.Name = "btnListar";
            btnListar.Size = new Size(94, 29);
            btnListar.TabIndex = 18;
            btnListar.Text = "Listar";
            btnListar.UseVisualStyleBackColor = true;
            // 
            // btnContarCuota
            // 
            btnContarCuota.Location = new Point(639, 73);
            btnContarCuota.Name = "btnContarCuota";
            btnContarCuota.Size = new Size(145, 29);
            btnContarCuota.TabIndex = 19;
            btnContarCuota.Text = "Contar Cuota al día";
            btnContarCuota.UseVisualStyleBackColor = true;
            // 
            // txtEdadFiltro
            // 
            txtEdadFiltro.Location = new Point(633, 129);
            txtEdadFiltro.Name = "txtEdadFiltro";
            txtEdadFiltro.Size = new Size(125, 27);
            txtEdadFiltro.TabIndex = 20;
            // 
            // btnFiltrarEdad
            // 
            btnFiltrarEdad.Location = new Point(773, 129);
            btnFiltrarEdad.Name = "btnFiltrarEdad";
            btnFiltrarEdad.Size = new Size(110, 29);
            btnFiltrarEdad.TabIndex = 21;
            btnFiltrarEdad.Text = "Filtrar > Edad";
            btnFiltrarEdad.UseVisualStyleBackColor = true;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(494, 266);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(125, 29);
            btnLimpiar.TabIndex = 22;
            btnLimpiar.Text = "Limpiar campos";
            btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // dgvSocios
            // 
            dgvSocios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSocios.Location = new Point(28, 380);
            dgvSocios.MultiSelect = false;
            dgvSocios.Name = "dgvSocios";
            dgvSocios.RowHeadersWidth = 51;
            dgvSocios.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSocios.Size = new Size(855, 168);
            dgvSocios.TabIndex = 23;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(909, 560);
            Controls.Add(dgvSocios);
            Controls.Add(btnLimpiar);
            Controls.Add(btnFiltrarEdad);
            Controls.Add(txtEdadFiltro);
            Controls.Add(btnContarCuota);
            Controls.Add(btnListar);
            Controls.Add(btnEliminar);
            Controls.Add(btnModificar);
            Controls.Add(btnAgregar);
            Controls.Add(chkCuotaAlDia);
            Controls.Add(label8);
            Controls.Add(dtpFechaNacimiento);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtNumeroSocio);
            Controls.Add(txtDNI);
            Controls.Add(txtApellido);
            Controls.Add(txtNombre);
            Controls.Add(label3);
            Controls.Add(txtId);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvSocios).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtId;
        private Label label3;
        private TextBox txtNombre;
        private TextBox txtApellido;
        private TextBox txtDNI;
        private TextBox txtNumeroSocio;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private DateTimePicker dtpFechaNacimiento;
        private Label label8;
        private CheckBox chkCuotaAlDia;
        private Button btnAgregar;
        private Button btnModificar;
        private Button btnEliminar;
        private Button btnListar;
        private Button btnContarCuota;
        private TextBox txtEdadFiltro;
        private Button btnFiltrarEdad;
        private Button btnLimpiar;
        private DataGridView dgvSocios;
    }
}
