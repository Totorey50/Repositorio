﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ClubWinForms
{
    public class SocioRepository
    {
        private readonly string connectionString;

        public SocioRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public List<Socio> GetAll()
        {
            var list = new List<Socio>();
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand("SELECT * FROM Socios", conn))
            {
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var socio = new Socio
                        {
                            Id = reader.GetInt32(reader.GetOrdinal("id")),
                            Nombre = reader.GetString(reader.GetOrdinal("nombre")),
                            Apellido = reader.GetString(reader.GetOrdinal("apellido")),
                            DNI = reader.GetString(reader.GetOrdinal("dni")),
                            FechaNacimiento = reader.GetDateTime(reader.GetOrdinal("fecha_nacimiento")),
                            NumeroSocio = reader.GetInt32(reader.GetOrdinal("numero_socio")),
                            CuotaAlDia = reader.GetBoolean(reader.GetOrdinal("cuota_al_dia"))
                        };
                        list.Add(socio);
                    }
                }
            }
            return list;
        }

        public void Add(Socio socio)
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(
                "INSERT INTO Socios (nombre, apellido, dni, fecha_nacimiento, numero_socio, cuota_al_dia) " +
                "VALUES (@nombre, @apellido, @dni, @fecha, @numero, @cuota)", conn))
            {
                cmd.Parameters.AddWithValue("@nombre", socio.Nombre);
                cmd.Parameters.AddWithValue("@apellido", socio.Apellido);
                cmd.Parameters.AddWithValue("@dni", socio.DNI);
                cmd.Parameters.AddWithValue("@fecha", socio.FechaNacimiento);
                cmd.Parameters.AddWithValue("@numero", socio.NumeroSocio);
                cmd.Parameters.AddWithValue("@cuota", socio.CuotaAlDia);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Update(Socio socio)
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(
                "UPDATE Socios SET nombre=@nombre, apellido=@apellido, dni=@dni, fecha_nacimiento=@fecha, numero_socio=@numero, cuota_al_dia=@cuota " +
                "WHERE id=@id", conn))
            {
                cmd.Parameters.AddWithValue("@nombre", socio.Nombre);
                cmd.Parameters.AddWithValue("@apellido", socio.Apellido);
                cmd.Parameters.AddWithValue("@dni", socio.DNI);
                cmd.Parameters.AddWithValue("@fecha", socio.FechaNacimiento);
                cmd.Parameters.AddWithValue("@numero", socio.NumeroSocio);
                cmd.Parameters.AddWithValue("@cuota", socio.CuotaAlDia);
                cmd.Parameters.AddWithValue("@id", socio.Id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Delete(int id)
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand("DELETE FROM Socios WHERE id=@id", conn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public int CountCuotaAlDia()
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand("SELECT COUNT(*) FROM Socios WHERE cuota_al_dia=1", conn))
            {
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public List<Socio> GetByAgeGreaterThan(int edad)
        {
            var list = new List<Socio>();
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(
                "SELECT * FROM Socios WHERE fecha_nacimiento <= DATEADD(YEAR, -@edad, GETDATE())", conn))
            {
                cmd.Parameters.AddWithValue("@edad", edad);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var socio = new Socio
                        {
                            Id = reader.GetInt32(reader.GetOrdinal("id")),
                            Nombre = reader.GetString(reader.GetOrdinal("nombre")),
                            Apellido = reader.GetString(reader.GetOrdinal("apellido")),
                            DNI = reader.GetString(reader.GetOrdinal("dni")),
                            FechaNacimiento = reader.GetDateTime(reader.GetOrdinal("fecha_nacimiento")),
                            NumeroSocio = reader.GetInt32(reader.GetOrdinal("numero_socio")),
                            CuotaAlDia = reader.GetBoolean(reader.GetOrdinal("cuota_al_dia"))
                        };
                        list.Add(socio);
                    }
                }
            }
            return list;
        }
    }
}
