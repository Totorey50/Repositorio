﻿using System;
using System.Windows.Forms;

namespace ClubWinForms

{
    public partial class Form1 : Form
    {
        private readonly SocioRepository repo;
        private readonly string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=club;Trusted_Connection=True;";

        public Form1()
        {
            InitializeComponent();

            // Configuración del DataGridView
            dgvSocios.AutoGenerateColumns = true;
            dgvSocios.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSocios.MultiSelect = false;

            // Inicializar repositorio
            repo = new SocioRepository(connectionString);
        }

        // 🔹 Cargar datos en el DataGridView
        private void CargarGrilla()
        {
            dgvSocios.DataSource = null;
            dgvSocios.DataSource = repo.GetAll();
        }

        // 🔹 Botón Listar
        private void btnListar_Click(object sender, EventArgs e)
        {
            CargarGrilla();
        }

        // 🔹 Botón Agregar
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            var socio = new Socio
            {
                Nombre = txtNombre.Text.Trim(),
                Apellido = txtApellido.Text.Trim(),
                DNI = txtDNI.Text.Trim(),
                FechaNacimiento = dtpFechaNacimiento.Value.Date,
                NumeroSocio = int.Parse(txtNumeroSocio.Text),
                CuotaAlDia = chkCuotaAlDia.Checked
            };

            repo.Add(socio);
            MessageBox.Show("Socio agregado con éxito");
            CargarGrilla();
            LimpiarCampos();
        }

        // 🔹 Botón Modificar
        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                MessageBox.Show("Selecciona un socio primero");
                return;
            }

            var socio = new Socio
            {
                Id = int.Parse(txtId.Text),
                Nombre = txtNombre.Text.Trim(),
                Apellido = txtApellido.Text.Trim(),
                DNI = txtDNI.Text.Trim(),
                FechaNacimiento = dtpFechaNacimiento.Value.Date,
                NumeroSocio = int.Parse(txtNumeroSocio.Text),
                CuotaAlDia = chkCuotaAlDia.Checked
            };

            repo.Update(socio);
            MessageBox.Show("Socio actualizado");
            CargarGrilla();
            LimpiarCampos();
        }

        // 🔹 Botón Eliminar
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                MessageBox.Show("Selecciona un socio primero");
                return;
            }

            int id = int.Parse(txtId.Text);
            repo.Delete(id);
            MessageBox.Show("Socio eliminado");
            CargarGrilla();
            LimpiarCampos();
        }

        // 🔹 Botón Contar cuota
        private void btnContarCuota_Click(object sender, EventArgs e)
        {
            int cantidad = repo.CountCuotaAlDia();
            MessageBox.Show("Socios con cuota al día: " + cantidad);
        }

        // 🔹 Botón Filtrar por edad
        private void btnFiltrarEdad_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtEdadFiltro.Text, out int edad))
            {
                MessageBox.Show("Edad inválida");
                return;
            }

            dgvSocios.DataSource = null;
            dgvSocios.DataSource = repo.GetByAgeGreaterThan(edad);
        }

        // 🔹 Cuando clickeás una fila en la grilla
        private void dgvSocios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var fila = dgvSocios.Rows[e.RowIndex];

            txtId.Text = fila.Cells["Id"].Value.ToString();
            txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
            txtApellido.Text = fila.Cells["Apellido"].Value.ToString();
            txtDNI.Text = fila.Cells["DNI"].Value.ToString();
            dtpFechaNacimiento.Value = Convert.ToDateTime(fila.Cells["FechaNacimiento"].Value);
            txtNumeroSocio.Text = fila.Cells["NumeroSocio"].Value.ToString();
            chkCuotaAlDia.Checked = Convert.ToBoolean(fila.Cells["CuotaAlDia"].Value);
        }

        // 🔹 Botón Limpiar
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        // 🔹 Método auxiliar
        private void LimpiarCampos()
        {
            txtId.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDNI.Text = "";
            txtNumeroSocio.Text = "";
            dtpFechaNacimiento.Value = DateTime.Today;
            chkCuotaAlDia.Checked = false;
        }
    }
}
