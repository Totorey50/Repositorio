﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica3
{
    internal class Socio
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int dni { get; set; }
        public DateTime FechaNacimineto { get; set; }

        public int NumeroSocio { get; set; }
        public bool CuotaPaga { get; set; }



    }
}
