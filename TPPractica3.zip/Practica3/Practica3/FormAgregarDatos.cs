﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    public partial class FormAgregarDatos : Form
    {
        private int? id;
        public FormAgregarDatos(int? id = null)
        {
            InitializeComponent();

            this.id = id;

            if (id != null)
            {
                LoadData();
            }
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            Repositorio repo = new Repositorio();

            try
            {
                if (id == null)
                {

                    Socio socio = new Socio
                    {

                        Nombre = txtnombre.Text,
                        Apellido = txtApellido.Text,
                        dni = int.Parse(txtDniSocio.Text),
                        FechaNacimineto = monthCalendar1.SelectionStart,
                        NumeroSocio = int.Parse(txtNumSocio.Text),
                        CuotaPaga = CuotaAlDiaCheck.Checked,

                    };

                    repo.AgregarDatos(socio);
                    MessageBox.Show("Datos Agregados crack");
                    Refresh();
                }else
                {
                    Socio socio = new Socio
                    {
                        Id = id.Value,
                        Nombre = txtnombre.Text,
                        Apellido = txtApellido.Text,
                        dni = int.Parse(txtDniSocio.Text),
                        FechaNacimineto = monthCalendar1.SelectionStart,
                        NumeroSocio = int.Parse(txtNumSocio.Text),
                        CuotaPaga = CuotaAlDiaCheck.Checked,

                    };

                    MessageBox.Show("Datos Modificados crack");
                    repo.ModificarDatos(socio);
                    Refresh();

                }

            }
            catch(Exception ex)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormListaSocios form = new FormListaSocios();
            form.Show();
            this.Hide();
        }

        public void LoadData()
        {
            Repositorio repo = new Repositorio();
            Socio socio = new Socio();
            socio = repo.ListarSocios().FirstOrDefault(x => x.Id == id.Value);

            if (socio != null)
            {
                txtnombre.Text = socio.Nombre;
                txtApellido.Text = socio.Apellido;
                txtDniSocio.Text = socio.dni.ToString();
                txtNumSocio.Text = socio.NumeroSocio.ToString();
                CuotaAlDiaCheck.Checked = socio.CuotaPaga;
            }
            
        }

        private void FormAgregarDatos_Load(object sender, EventArgs e)
        {

        }
    }
}
