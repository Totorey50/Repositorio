﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    public partial class FormListaSocios : Form
    {
        public FormListaSocios()
        {
            InitializeComponent();
            Refresh();
        }

        private void FormListaSocios_Load(object sender, EventArgs e)
        {

        }


        public void Refresh()
        {
            dataGridView1.DataSource = null;
            Repositorio repo = new Repositorio();
            dataGridView1.DataSource = repo.ListarSocios();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int? id = GetId();

            if (id == null)
            {
                MessageBox.Show("Eliga uno a eliminar");
            }else
            {
                Repositorio repo = new Repositorio();

                repo.EliminarSocio((int)id);
            }

            Refresh();
        }



        private int? GetId()
        {
            if (dataGridView1.CurrentRow == null)
                return null;

            return int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

            int? id = GetId();
            try
            {
                FormAgregarDatos form = new FormAgregarDatos(id);
                form.Show();
                this.Hide();

            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Repositorio repo = new Repositorio();
            try
            {
                repo.CalcularCuotasPagas();

            }
            catch (Exception ex)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormEdad form = new FormEdad();
            form.Show();
            this.Hide();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
