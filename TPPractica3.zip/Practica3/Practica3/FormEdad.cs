﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    public partial class FormEdad : Form
    {
        public FormEdad()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            Repositorio repo = new Repositorio();

            try
            {

                int edad = int.Parse(textBox1.Text);
                var buscarEdad = repo.CalcularEdadSocio(edad);

                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Ingrese una edad");
                }else
                {
                    if (buscarEdad.Count == 0)
                    {
                        MessageBox.Show($"No existe Socio mayor a {edad}");
                    }else
                    {
                        foreach (var x in buscarEdad)
                        {

                            MessageBox.Show($"El Socio {x.Nombre} DNI: {x.dni} Fecha de nacimiento {x.FechaNacimineto.ToShortDateString()} ");

                        }

                    }

                }
            }
            catch
            {
                MessageBox.Show("Error al calcular");
            }

        }

        private void FormEdad_Load(object sender, EventArgs e)
        {

        }
    }
}
