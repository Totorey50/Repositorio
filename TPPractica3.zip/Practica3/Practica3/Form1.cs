﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAgregarSocioForm_Click(object sender, EventArgs e)
        {
            FormAgregarDatos form = new FormAgregarDatos();
            form.Show();
            this.Hide();
        }

        private void btnListaSociosForm_Click(object sender, EventArgs e)
        {
            FormListaSocios form = new FormListaSocios();
            form.Show();
            this.Hide();
        }
    }
}
