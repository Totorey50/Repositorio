﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica3
{
    internal class Repositorio
    {

        private string conectionString = "Server=DESKTOP-G3BKE2J\\SQLEXPRESS;Database=club;Trusted_Connection=True;";

        private List<Socio> listaSocios;
        private List<Socio> listaSociosEdades;



        public Repositorio()
        {
            listaSocios = new List<Socio>();
            listaSociosEdades = new List<Socio>();
        }



        public List<Socio> ListarSocios()
        {
            using (SqlConnection conn = new SqlConnection(conectionString))
            {
                conn.Open();

                string query = "SELECT id, nombre, apellido, dni, fecha_nacimiento, numero_socio, cuota_al_dia FROM Socios";

                using (SqlCommand comando = new SqlCommand(query, conn))
                using (SqlDataReader reader = comando.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Socio socio = new Socio
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            Nombre = reader["nombre"].ToString(),
                            Apellido = reader["apellido"].ToString(),
                            dni = Convert.ToInt32(reader["dni"]),
                            FechaNacimineto = Convert.ToDateTime(reader["fecha_nacimiento"]),
                            NumeroSocio = Convert.ToInt32(reader["numero_socio"]),
                            CuotaPaga = Convert.ToBoolean(reader["cuota_al_dia"])
                        };

                        listaSocios.Add(socio);
                    }

                }
            }
            return listaSocios;
        }



        public void AgregarDatos(Socio socio)
        {
            using (SqlConnection conn = new SqlConnection(conectionString))
            {
                conn.Open();

                string query = "INSERT INTO Socios (nombre, apellido, dni, fecha_nacimiento, numero_socio, cuota_al_dia)" +
                    "VALUES (@nombre, @apellido, @dni, @fecha_nacimiento, @numero_socio, @cuota_al_dia)";

                using (SqlCommand comando = new SqlCommand(query, conn))
                {
                    comando.Parameters.AddWithValue("nombre", socio.Nombre);
                    comando.Parameters.AddWithValue("apellido", socio.Apellido);
                    comando.Parameters.AddWithValue("dni", socio.dni);
                    comando.Parameters.AddWithValue("fecha_nacimiento", socio.FechaNacimineto);
                    comando.Parameters.AddWithValue("numero_socio", socio.NumeroSocio);
                    comando.Parameters.AddWithValue("cuota_al_dia", socio.CuotaPaga);
                    comando.ExecuteNonQuery();


                }
            }
        }


        public void EliminarSocio(int id)
        {
            using (SqlConnection conn = new SqlConnection(conectionString))
            {
                conn.Open();


                string query = "DELETE FROM Socios WHERE id = @id";

                using (SqlCommand comando = new SqlCommand(query, conn))
                {
                    comando.Parameters.AddWithValue("@id", id);
                    comando.ExecuteNonQuery();

                }
            }
        }


        public void ModificarDatos(Socio socio)
        {
            using (SqlConnection conn = new SqlConnection(conectionString))
            {
                conn.Open();

                string query = "UPDATE Socios set nombre = @nombre, apellido = @apellido, dni = @dni, fecha_nacimiento = @fecha_nacimiento, numero_socio = @numero_socio, cuota_al_dia = @cuota_al_dia"
                    + " Where id = @id";

                using (SqlCommand comando = new SqlCommand(query, conn))
                {
                    comando.Parameters.AddWithValue("id", socio.Id);
                    comando.Parameters.AddWithValue("nombre", socio.Nombre);
                    comando.Parameters.AddWithValue("apellido", socio.Apellido);
                    comando.Parameters.AddWithValue("dni", socio.dni);
                    comando.Parameters.AddWithValue("fecha_nacimiento", socio.FechaNacimineto);
                    comando.Parameters.AddWithValue("numero_socio", socio.NumeroSocio);
                    comando.Parameters.AddWithValue("cuota_al_dia", socio.CuotaPaga);
                    comando.ExecuteNonQuery();

                }
            }


        }
        public void CalcularCuotasPagas()
        {
            int cuotasPagas = 0;

            using (SqlConnection conn = new SqlConnection(conectionString))
            {
                conn.Open();

                string query = "SELECT cuota_al_dia FROM Socios";

                using (SqlCommand comando = new SqlCommand(query, conn))
                using (SqlDataReader reader = comando.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        bool cuota = Convert.ToBoolean(reader["cuota_al_dia"]);

                        if (cuota != false)
                        {
                            cuotasPagas++;
                        }
                    }

                }


                MessageBox.Show($"La cantidad de Socios con la cuotas pagas es de: {cuotasPagas}");

            }
        }

        public List<Socio> CalcularEdadSocio(int edad)
        {
            using (SqlConnection conn = new SqlConnection(conectionString))
            {
                conn.Open();

                DateTime fechaLimite = DateTime.Now.AddYears(-edad);

                string query = "SELECT id, nombre, apellido, dni, fecha_nacimiento, numero_socio, cuota_al_dia " + "FROM Socios WHERE fecha_nacimiento <= @fechaLimite";

                using (SqlCommand comando = new SqlCommand(query, conn))
                {

                    comando.Parameters.AddWithValue("@fechaLimite", fechaLimite);

                    using (SqlDataReader reader = comando.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Socio socio = new Socio
                            {
                                Id = Convert.ToInt32(reader["id"]),
                                Nombre = reader["nombre"].ToString(),
                                Apellido = reader["apellido"].ToString(),
                                dni = Convert.ToInt32(reader["dni"]),
                                FechaNacimineto = Convert.ToDateTime(reader["fecha_nacimiento"]),
                                NumeroSocio = Convert.ToInt32(reader["numero_socio"]),
                                CuotaPaga = Convert.ToBoolean(reader["cuota_al_dia"])
                            };

                            listaSociosEdades.Add(socio);


                        }
                    }

                }
            }


            return listaSociosEdades;
        }




    }




    
}
